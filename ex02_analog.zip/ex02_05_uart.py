from machine import Pin,UART
from utime import sleep
import ujson

uart1 = UART(1,baudrate=9600, tx=Pin(4), rx=Pin(5))
uart1.init(bits=8, parity=None, stop=1)

led = Pin('LED', Pin.OUT)

payload = {
    "command": "start",   
    "value": 10
}

while True:
    uart1.write(ujson.dumps(payload) + "\n")
    if uart1.any():
        char = uart1.read()
        if char == b'x':
            led.toggle()
    sleep(0.5)

