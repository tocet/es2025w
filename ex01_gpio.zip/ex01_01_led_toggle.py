import machine
import utime as t

led_builtin = machine.Pin('LED',machine.Pin.OUT)
i = 0
# this is a comment
while True:
    led_builtin.toggle()
    t.sleep(0.5)
    i+=1
    print(f'Current interation is {i}')
    