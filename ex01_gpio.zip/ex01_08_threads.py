from utime import sleep
import _thread

def core0():
    global lock
    while True:
        lock.acquire()
        print('C')
        sleep(0.5)
        print('O')
        sleep(0.5)
        print('R')
        sleep(0.5)
        print('E')
        sleep(0.5)
        print('0')
        sleep(0.5)
        lock.release()

def core1():
    global lock
    while True:
        lock.acquire()
        print('c')
        sleep(0.5)
        print('o')
        sleep(0.5)
        print('r')
        sleep(0.5)
        print('e')
        sleep(0.5)
        print('1')
        sleep(0.5)
        lock.release()

lock = _thread.allocate_lock()

_thread.start_new_thread(core1, ())
core0()