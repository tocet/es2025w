from utime import sleep
import _thread

def core0():
    global core1_takes_control
    counter = 0
    while True:
        for _ in range(3):
            print(f' Counter value = {counter}')
            counter += 1
            sleep(1)

        core1_takes_control = True

        print("Core 0 is waiting") 
        while core1_takes_control:
            pass

def core1():
    global core1_takes_control
    counter = 100
    while True:
        print("Core 1 is waiting")
        while not core1_takes_control:
            pass

        for _ in range(3):
            print(f'Counter value = {counter}')
            counter += 10
            sleep(2)

        core1_takes_control = False


core1_takes_control = False

second_thread = _thread.start_new_thread(core1,())
core0()