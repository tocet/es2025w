from machine import Pin
from utime import sleep

button = Pin(14,Pin.IN,Pin.PULL_DOWN)
led = Pin(15,Pin.OUT)

def led_blink(pin,times):
    for i in range(times):
        pin.toggle()
        sleep(0.5)
        pin.toggle()
        sleep(0.5)

led.value(0)

while True:
    if button.value() == 1:
        led_blink(led,5) 
    sleep(0.1)