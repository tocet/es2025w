from machine import Pin
import utime

button = Pin(14,Pin.IN,Pin.PULL_DOWN)
led = Pin(15,Pin.OUT)
led.value(1)

while True:
    if button.value() == 1:
        led.value(0)
    else:
        led.value(1)    
    utime.sleep(0.1)