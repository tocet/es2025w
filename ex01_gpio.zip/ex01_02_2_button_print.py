from machine import Pin
from utime import sleep

button = Pin(14,Pin.IN,Pin.PULL_DOWN)
message = input("Enter the message: ")
print('This is the message: ' + message)

while True:
    if button.value() == 1:
        print(message)
        sleep(0.5)